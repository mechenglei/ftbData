# ftbData
ftbData是一个足球比赛数据统计的工具。

##　Usage

from ftbData import games

games.get_today()  
games.get_today(odds=True)  
games.get_his(start='20170101', end='20170102')  
games.get_team(u'巴塞罗那')  
games.get_rank(u'西甲')  



