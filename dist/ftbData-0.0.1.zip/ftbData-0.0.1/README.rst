# ftbData
ftbData是一个足球比赛数据统计的工具。

##　Usage

from ftbData import games

games.get_today()
games.get_today(odds=True)
games.get_his()
games.get_team(u'巴塞罗那')
games.get_event_rank(u'西甲')



